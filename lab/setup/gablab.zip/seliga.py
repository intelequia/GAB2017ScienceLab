################################################################################
# 
#       Copyright (C) 2017 Sebastian L. Hidalgo
#       shidalgo@iac.es
#
#       This program is free software: you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation, version 3 of the License GPLv3.
#   
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#   
#       You should have received a copy of the GNU General Public License
#       along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#       Sebastian L. Hidalgo 
#       Instituto de Astrofisica de Canarias
#       C/ Via Lactea s/n
#       38200 La Laguna
#       S. C. Tenerife
#       SPAIN
#
# 
##################################################################################

############################# BLOCK PACKAGES IMPORT #############################
# FOR COUNTING STARS:
import argparse as argp
from glob import glob
import numpy as np
import os
import matplotlib.path as ph
import scipy.interpolate as itl
import scipy.ndimage.interpolation as scr

workspace = "/tmp/gablab/"

############################# BLOCK OPTIONS INPUT ###############################

parser = argp.ArgumentParser(prog='seliga.py',description='This is a Python3 algorithm to perform a pseudo deconvolution '
                    ' by a combination of a Montecarlo simulation with a 2D pseudo-convolution. '
                    ' It takes a test funcion -or a set of them-, a impulse response function, and '
                    ' a target one. It convolves the test function with the impuse response funcion '
                    ' showing the fraction (in area) that the result of the convolution share with the target one-'
                    ' a log file will be storaged in a minniacDATE.log file'                     
                    'for xcent, ycent, xscal, yscal, sfr0, rot, and npt: if 3 numbers are given, it takes them as: first, end, number_of_samples',
                    usage='%(prog)s')

parser.add_argument('--version', action='version', version='%(prog)s 1.0')

parser.add_argument('tstfun', type=str, help='test functions '
                    'keywords: gaussian-ellipsoid-polyhedron')

parser.add_argument('irpfun', type=str, help='impulse response functions')

parser.add_argument('obsfun', type=str, help='observed function')

parser.add_argument('xlims', nargs=2, type=float, help='x-0, x-end limits for the columns (ages)')

parser.add_argument('ylims', nargs=2, type=float, help='y-0, y-end limits for the rows (metallicities)')

parser.add_argument('out', type=str, help='file with results: test_function, parameters, score')

parser.add_argument('-xcent', nargs='+', default=[0], type=float, help='X-center(s) for the test function ')

parser.add_argument('-ycent', nargs='+', default=[0], type=float, help='Y-center for the test function')

parser.add_argument('-xscal', nargs='+', default=[1], type=float, help='X-scale(s) for the test function ')

parser.add_argument('-yscal', nargs='+', default=[1], type=float, help='Y-scale(s) for the test function')

parser.add_argument('-sr0', nargs='+', default=[1], type=float, help='Z-scale')

parser.add_argument('-rot', nargs='+', default=[0], type=float, help='rotation')

parser.add_argument('-npt', nargs='+', default=[3], type=int, help='Num. vertex')

parser.add_argument('-xng', nargs='+', default = [0e9, 12.5e9], type=float, help='X-nodes for gradients')
                                                              
parser.add_argument('-yng', nargs='+', default = [0, 0.1], type=float, help='Y-nodes for gradients')
                                                              
parser.add_argument('-xsg', nargs='+', default = [1, 1], type=float, help='Gradients in X-nodes')
                                                              
parser.add_argument('-ysg', nargs='+', default = [1, 1], type=float, help='Gradients in Y-nodes')


# args = parser.parse_args()

# args = parser.parse_args('polyhedron BRESP/sampleB-resp*.dat sfhtestB-obs.dat 0 13.5e9 0.001 0.008 results.dat -xcent 10.5e9 -ycent 0.004 -xscal 1e9 -yscal 0.002 -sr0 0.083 -rot 0 -npt 4 -xng 10e9 11e9 -yng 0.003 0.005 -xsg 1 1 -ysg 1 1'.split()) 

# args = parser.parse_args('polyhedron BRESP/sampleB-resp*.dat FUNC/mockobs-sampleB014099.dat 0 13.5e9 0.001 0.008 results.dat -xcent  1.2e+10  -ycent  0.004 -xscal  2e+08  -yscal  0.001  -sr0   0.1 -rot  0 90 3  -npt 4  -xng  1.18e+10  1.19e+10       1.2e+10  1.21e+10  1.22e+10  -yng  0.0008  0.0009  0.001  0.0011   0.0012  -xsg 1  1  1  1  1  1  1  -ysg  1  1  1  1'.split())

args = parser.parse_args(input().split())


############################# BLOCK SETTING CONSTANTS #############################
tstfix = ['gaussian', 'ellipsoid', 'polyhedron']
tstnam = ['gssfn', 'elpfn', 'polfn']
tolr = 1e-12 # MINIMUM VALUE FOR SFR BELOW THAT WILL BE 0


############################# BLOCK READING INPUT #############################
tstfun = args.tstfun.split('-')
atstfun =[]
for tfn in tstfun:
    if tstfix.count(tfn) < 1:
       readfun = True
       atstfun=glob(args.tstfun)    
    else:
        readfun = False
        atstfun.append(tstnam[tstfix.index(tfn)])
  
airpfun = sorted(glob(workspace + args.irpfun))
obsfun = np.loadtxt(workspace + args.obsfun)

if len(args.xcent) == 3 and len(args.ycent) == 3:
    ncent = int(max([args.xcent[2],args.ycent[2]]))

if len(args.xcent) == 3:
    axcent = np.linspace(args.xcent[0],args.xcent[1],ncent)
else:
    axcent = args.xcent

if len(args.ycent) == 3:
    aycent = np.linspace(args.ycent[0],args.ycent[1],ncent)
else:
    aycent = args.ycent

xycent = np.array([axcent,aycent]).T

if len(args.xscal) == 3:
    axscal = np.linspace(args.xscal[0],args.xscal[1],int(args.xscal[2]))
else:
    axscal = args.xscal

if len(args.yscal) == 3:
    ayscal = np.linspace(args.yscal[0],args.yscal[1],int(args.yscal[2]))
else:
    ayscal = args.yscal

if len(args.sr0) == 3:
    asr0 = np.linspace(args.sr0[0],args.sr0[1],int(args.sr0[2]))
else:
    asr0 = args.sr0

if len(args.rot) == 3:
    arot = np.linspace(args.rot[0],args.rot[1],int(args.rot[2]))
else:
    arot = args.rot

if len(args.npt) == 3:
    anpt = np.linspace(args.npt[0],args.npt[1],int(args.npt[2])).astype(int)
else:
    anpt = args.npt

xng = args.xng
yng = args.yng
xsg = args.xsg
ysg = args.ysg

if len(xng) != len(xsg):
    n = min([len(xng),len(xsg)])
    xng = xng[0:n]
    xsg = xsg[0:n]

if len(yng) != len(ysg):
    ysg = ysg[0:len(yng)]
    n = min([len(yng),len(ysg)])
    yng = yng[0:n]
    ysg = ysg[0:n]

xysng = xng + yng + xsg + ysg


hdlout = open(args.out,'w')


s = '#FUNOBS                   FUNTEST          FUNRESP                           X0           Y0          XS          YS          SFR0          ROT        VERTX     '+'XNODE      '*len(xng) + '  YNODE     '*len(yng) + '   XSNODE   '*len(xsg) + '   YSNODE   '*len(ysg) + ' MSE  ' + '      SCORE\n'
hdlout.write(s)

obsfun = np.loadtxt(workspace + args.obsfun)

age = np.linspace(args.xlims[0],args.xlims[1],obsfun.shape[1]+1)
met = np.linspace(args.ylims[0],args.ylims[1],obsfun.shape[0]+1)


############################# BLOCK FUNCITIONS #############################

# FIXED FUNCTIONS
# 2D GAUSSIAN FUNCTION 
# x0 = node x-center
# y0 = node y-center
# xr = x sigma
# yr = y sigma
# ag  = x nodes
# mt  = y nodes
# sr0 = z scale 
# rot = rotation
# dum = dummy parameter

def gssfn(x0,y0,xr,yr,ag,mt,sr0,rot,dum1,dum2,dum3,dum4,dum5):
    msq = np.zeros((len(mt)-1,len(ag)-1))
    theta = rot/180.*np.pi 

    # PIVOT FOR ROTATION
    agg = []
    mtg = []
    for aa in np.arange(len(ag)-1):
        agg.append((ag[aa]+ag[aa+1])/2)
        
    for mm in np.arange(len(mt)-1):
        mtg.append((mt[mm]+mt[mm+1])/2)

    agg = np.array(agg)
    mtg = np.array(mtg)

    pva=np.where(agg>=x0)[0][0]
    pvm=np.where(mtg>=y0)[0][0]
    
    # axes normalization 
    rage = (ag[-1]-ag[0])
    rmet = (mt[-1]-mt[0])
    x0 = x0 / rage
    y0 = y0 / rmet
    xr = ( xr / rage )**2
    yr = ( yr / rmet )**2
   
    for aa in np.arange(len(ag)-1):
        for mm in np.arange(len(mt)-1):
            x = np.mean([ag[aa],ag[aa+1]])/rage  
            y = np.mean([mt[mm],mt[mm+1]])/rmet
            msq[mm,aa] = np.exp(- ( (x - x0)**2/(2*xr) + (y - y0)**2/(2*yr) ) )

    # ROTATION
    padX = [msq.shape[1] - pva, pva]
    padY = [msq.shape[0] - pvm, pvm]
    imgP = np.pad(msq, [padY, padX], 'constant')
    imgR = scr.rotate(imgP, rot, reshape=False)
    msq  = imgR[padY[0] : -padY[1], padX[0] : -padX[1]]
    
    return msq * sr0


# ELLIPSOID FUNCTION 
# x0 = node x-center
# y0 = node y-center
# xr = x radius
# yr = y radius
# ag  = x nodes
# mt  = y nodes
# sr0 = z scale
# rot = rotation
# dum = dummy parameter

def elpfn(x0,y0,xr,yr,ag,mt,sr0,rot,dum,xn,yn,sx,sy):
    theta = rot/180.*np.pi  

    # GRADIENT
    agg = []
    mtg = []
    for aa in np.arange(len(ag)-1):
        agg.append((ag[aa]+ag[aa+1])/2)
        
    for mm in np.arange(len(mt)-1):
        mtg.append((mt[mm]+mt[mm+1])/2)

    agg = np.array(agg)
    mtg = np.array(mtg)

    # PIVOT FOR ROTATION
    pva=np.where(agg>=x0)[0][0]
    pvm=np.where(mtg>=y0)[0][0]
    
    
    lx  = (agg < xn[0]) 
    xgr = list(np.linspace(0.,0.,sum(lx)))
    
    for n in np.arange(0,len(xn)-1):
        lx  = (agg >= xn[n]) & (agg < xn[n+1])
        xgr = xgr + list(np.linspace(sx[n],sx[n+1],sum(lx)))
        
    lx  = (agg > xn[-1]) 
    xgr = xgr + list(np.linspace(0.,0.,sum(lx)))        
    
    
    lx  = (mtg < yn[0]) 
    ygr = list(np.linspace(0.,0.,sum(lx)))        

    for n in np.arange(0,len(yn)-1):
        lx  = (mtg >= yn[n]) & (mtg < yn[n+1])
        ygr = ygr + list(np.linspace(sy[n],sy[n+1],sum(lx)))
        
    lx  = (mtg > yn[-1]) 
    ygr = ygr + list(np.linspace(0.,0.,sum(lx)))        
    
    zgr = []
    for a in np.arange(len(agg)):
        for m in np.arange(len(mtg)):
            zgr.append(xgr[a]*ygr[m])

    zgr = np.array(zgr)*sr0        
    fgr = itl.interp2d(agg,mtg,zgr,kind='linear')
    fgr = fgr(agg,mtg)

  
    # axes normalization 
    rage = (ag[-1]-ag[0])
    rmet = (mt[-1]-mt[0])
    x0 = x0 / rage
    y0 = y0 / rmet
    xr = xr / rage
    yr = yr / rmet

    tng = np.linspace(0,359,360)/180*np.pi
    x = x0 + xr * np.cos(tng) * np.cos(theta) - yr * np.sin(tng) * np.sin(theta)
    y = y0 + xr * np.cos(tng) * np.sin(theta) + yr * np.sin(tng) * np.cos(theta)
        
    pol = ph.Path(np.array([x, y]).T)    
    
    msq = np.zeros((len(mt)-1,len(ag)-1))
    for aa in np.arange(len(ag)-1):
        for mm in np.arange(len(mt)-1):
            xym = [(ag[aa]+ag[aa+1])/2/rage, (mt[mm]+mt[mm+1])/2/rmet] 
            msq[mm,aa] = int(pol.contains_point(xym))
    
    # ROTATION
    padX = [msq.shape[1] - pva, pva]
    padY = [msq.shape[0] - pvm, pvm]
    imgP = np.pad(msq, [padY, padX], 'constant')
    imgR = scr.rotate(imgP, rot, reshape=False)
    msq  = imgR[padY[0] : -padY[1], padX[0] : -padX[1]]
    
    padX = [fgr.shape[1] - pva, pva]
    padY = [fgr.shape[0] - pvm, pvm]
    imgP = np.pad(fgr, [padY, padX], 'constant')
    imgR = scr.rotate(imgP, rot, reshape=False)
    fgr  = imgR[padY[0] : -padY[1], padX[0] : -padX[1]]

    return msq * fgr

# POLIEDRIC FUNCTION 
# x0 = node x-center
# y0 = node y-center
# xr = x radius
# yr = y radius
# ag  = x nodes
# mt  = y nodes
# sr0 = z scale
# rot = rotation
# npt = number of vertexs
# xn = list with the x-nodes for the gradient
# yn = list with the y-nodes for the gradient
# sx = fraction of sr0 at each xn node
# sy = fraction of sr0 at each xn node



def polfn(x0,y0,xr,yr,ag,mt,sr0,rot,npt,xn,yn,sx,sy):  
    msq = np.zeros((len(mt)-1,len(ag)-1))
   
    theta = rot/180.*np.pi  
    tng = np.arange(0+np.pi/npt,2*np.pi+np.pi/npt,2*np.pi/npt)

    # GRADIENT
    agg = []
    mtg = []
    for aa in np.arange(len(ag)-1):
        agg.append((ag[aa]+ag[aa+1])/2)
        
    for mm in np.arange(len(mt)-1):
        mtg.append((mt[mm]+mt[mm+1])/2)

    agg = np.array(agg)
    mtg = np.array(mtg)

    # PIVOT FOR ROTATION
    pva=np.where(agg>=x0)[0][0]
    pvm=np.where(mtg>=y0)[0][0]
    
    
    lx  = (agg < xn[0]) 
    xgr = list(np.linspace(0.,0.,sum(lx)))

    for n in np.arange(0,len(xn)-1):
        lx  = (agg >= xn[n]) & (agg < xn[n+1])
        xgr = xgr + list(np.linspace(sx[n],sx[n+1],sum(lx)))
        
    lx  = (agg > xn[-1]) 
    xgr = xgr + list(np.linspace(0.,0.,sum(lx)))        
        
    lx  = (mtg < yn[0]) 
    ygr = list(np.linspace(0.,0.,sum(lx)))        

    for n in np.arange(0,len(yn)-1):
        lx  = (mtg >= yn[n]) & (mtg < yn[n+1])
        ygr = ygr + list(np.linspace(sy[n],sy[n+1],sum(lx)))
        
    lx  = (mtg > yn[-1]) 
    ygr = ygr + list(np.linspace(0.,0.,sum(lx)))        
    
    zgr = []
    for a in np.arange(len(agg)):
        for m in np.arange(len(mtg)):
            zgr.append(xgr[a]*ygr[m])

    zgr = np.array(zgr)*sr0        
    fgr = itl.interp2d(agg,mtg,zgr,kind='linear')
    fgr = fgr(agg,mtg)

    # axes normalization 
    rage = (ag[-1]-ag[0])
    rmet = (mt[-1]-mt[0])
    x0 = x0 / rage
    y0 = y0 / rmet
    xr = xr / rage
    yr = yr / rmet
    
    # POLIEDRIC REGION
    x = x0 + xr * np.cos(tng) * np.cos(np.pi/npt)
    y = y0 + yr * np.sin(tng) * np.sin(np.pi/npt)
    pol = ph.Path(np.array([x, y]).T) 
    
    
    for aa in np.arange(len(ag)-1):
        for mm in np.arange(len(mt)-1):
            xym = [(ag[aa]+ag[aa+1])/2/rage, (mt[mm]+mt[mm+1])/2/rmet] 
            msq[mm,aa] = int(pol.contains_point(xym))
    
    
    # ROTATION
    padX = [msq.shape[1] - pva, pva]
    padY = [msq.shape[0] - pvm, pvm]
    imgP = np.pad(msq, [padY, padX], 'constant')
    imgR = scr.rotate(imgP, rot, reshape=False)
    msq  = imgR[padY[0] : -padY[1], padX[0] : -padX[1]]
    
    padX = [fgr.shape[1] - pva, pva]
    padY = [fgr.shape[0] - pvm, pvm]
    imgP = np.pad(fgr, [padY, padX], 'constant')
    imgR = scr.rotate(imgP, rot, reshape=False)
    fgr  = imgR[padY[0] : -padY[1], padX[0] : -padX[1]]
    
    return msq * fgr

def sfhcheck(cfun,ag,mt,xyr,arpf,tlr):
    l = np.where(cfun > tlr)
    ll = []
    tmass = []
    for k in np.asarray(l).T:
        tmass.append(cfun[k[0],k[1]])
        mag=(ag[k[1]]+ag[k[1]+1])/2
        mmt=(mt[k[0]]+mt[k[0]+1])/2
        ll.append(np.where((xyr[:,0]<=mag) & (xyr[:,1]>=mag) & (xyr[:,2]<=mmt) & (xyr[:,3]>=mmt))[0][0])

    sfc = np.zeros((cfun.shape[0],cfun.shape[1]))
    for n in np.arange(len(ll)):
        rpf = []      
        with open(arpf[ll[n]]) as filer:
            filer.readline()
            for lin in filer:
                rpf.append(lin.split())
        
        rpf = np.array(rpf).astype(float)
        rpf = rpf / sum(sum(rpf)) * tmass[n]
        if (sfc.shape[0] == rpf.shape[0]) and (sfc.shape[1] == rpf.shape[1]):
            sfc = sfc + rpf
        
    return sfc

# SAMPLING FUNCTION
def msample(pfun,pxycent,paxscal,payscal,pasr0,parot,panpt):
    if pfun=='gssfn':
        ms = [(a,b,c,d,e,f) for a in pxycent for b in paxscal for c in payscal for d in pasr0 for e in parot for f in [panpt[0]]]

    else: 
        ms = [(a,b,c,d,e,f) for a in pxycent for b in paxscal for c in payscal for d in pasr0 for e in parot for f in panpt]

    return ms

# MERIT FUNCTION 
# Structural Similarity Index (Wang, Z. et al. 2004 IEEE, 13, 4, 600). Varies between -1 and +1 with +1 being a perfect match

def funcomp(img1,img2,wnd):
    ssim = []     
    pix = [[x,y] for x in np.arange(img1.shape[0]) for y in np.arange(img1.shape[1])]
    pix = np.array(pix).astype(int)
    for n in pix:
        l = (pix[:,0] - n[0])**2 + (pix[:,1] - n[1])**2 <= wnd**2
        mx  = np.mean(img1.ravel()[l])
        my  = np.mean(img2.ravel()[l])
        vx  = np.var(img1.ravel()[l])
        vy  = np.var(img2.ravel()[l])
        cxy = np.mean((img1.ravel()[l]-mx)*(img2.ravel()[l]-my))
        ssim.append( (2*mx*my + 1e-5) * (2*cxy + 1e-5) / ((mx**2 + my**2 + 1e-5)*(vx + vy + 1e-5)) )
    return np.mean(np.array(ssim).astype(float))

################################### BLOCK FOR CALCULATIONS #############################

xyresp = []

for n in np.arange(len(airpfun)):
    x = []
    with open(airpfun[n]) as filer:
        xyresp.append(filer.readline().split())

xyresp = np.array(xyresp).astype(float)

if readfun: 
     
    tstfun = np.loadtxt(ntstfun)
    sfhcon = sfhcheck(tfun,age,met,xyresp,airpfun,tolr)    
    mse = sum(sum((sfhcon-obsfun)**2))/(sfhcon.shape[0]*sfhcon.shape[1])  # MEAN SQUARED ERROR
    score = funcomp(sfhcon,obsfun,2)*100
    t = [args.obsfun, tstfun, args.irpfun,  np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan] + list([mse]) + list([score])
    hdlout.write(('%s   %s    %s    '+'%12g'*(len(t)-3)+'\n')  % tuple(t))
    
else: 
    for ntstfun in atstfun:
        tstfun = eval(ntstfun)
        #mdat = [(a,b,c,d,e,f) for a in xycent for b in axscal for c in ayscal for d in asr0 for e in arot for f in anpt]
        mdat = msample(ntstfun,xycent,axscal,ayscal,asr0,arot,anpt)    
    
        for nd in mdat:
            tfun = tstfun(nd[0][0],nd[0][1],nd[1],nd[2],age,met,nd[3],nd[4],nd[5],xng,yng,xsg,ysg)

            if tfun.shape[0]*tfun.shape[1] > 1:
                sfhcon = sfhcheck(tfun,age,met,xyresp,airpfun,tolr)
                mse = sum(sum((sfhcon-obsfun)**2))/(sfhcon.shape[0]*sfhcon.shape[1])  # MEAN SQUARED ERROR
                score = funcomp(sfhcon,obsfun,2)*100
            else:
                mse = np.nan
                score = -100.000

            t = [args.obsfun, ntstfun, args.irpfun, nd[0][0], nd[0][1], nd[1], nd[2], nd[3], nd[4], nd[5]]+ xysng + list([mse]) + list([score])
            hdlout.write(('%s   %s    %s    '+'%12g'*(len(t)-3)+'\n')  % tuple(t))
 
hdlout.close()

